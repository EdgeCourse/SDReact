import React from 'react';

export const Logout = () => {
  console.log("Logout");
  return (
    <h1>Logout</h1>
  )
}